package com.titaniam.db.dbserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
